#include <QCoreApplication>

#include "multicastfileclient.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);


    // CLIENT için ayrı program olarak çalıştırılacak

    // MulticastClient client;
     //client.start();

     MulticastClient client;

     QObject::connect(&client, &MulticastClient::fileReceived,
                      [](QString path, QString name, QString id, QString type,bool overWrite)
                      {
                          qDebug() << "CLIENT FILE DONE:";
                          qDebug() << "Path:" << path;
                          qDebug() << "Name:" << name;
                          qDebug() << "Type:" << type;
                          qDebug() << "TransferId:" << id;
                          qDebug() << "OverWrite:" << overWrite;
                      });
     QObject::connect(&client, &MulticastClient::transferProgress,
                      [](int p)
     {
         qDebug() << "Progress:" << p << "%";
     });

     //QTimer::singleShot(0, [&](){
         client.start();
     //});
    return a.exec();
}
