#include <QCoreApplication>
#include "multicastfileserver.h"


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // SERVER için
     //MulticastServer server(QString("/home/etapadmin/ab.deb"));
    //MulticastServer server("/home/etapadmin/ab.deb");
    ///server.start();
    MulticastServer server("/home/etapadmin/ab.deb");

        QObject::connect(&server, &MulticastServer::transferFinished,
                         [](QString sender, QString receiver, QString file, QString id)
        {
            qDebug() <<"Client Tamamlandı: "<< sender << file << id;
        });

        server.allowedClients << "192.168.23.245"
                            << "192.168.23.241"
                            << "192.168.23.251";

        QTimer::singleShot(0, [&](){
            server.start();
        });
    // CLIENT için ayrı program olarak çalıştırılacak
    // MulticastClient client;
    // client.start();

    return a.exec();
}
