#include "multicastfileclient.h"

MulticastClient::MulticastClient(QObject *parent)
    : QObject(parent), totalPackets(0), currentTransferId(0), allowed(true)
{}

void MulticastClient::log(const QString &msg)
{
    QString ts = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    qDebug() << ts << msg;
}

QString MulticastClient::getLocalIp()
{
    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces())
    {
        if (!(iface.flags() & QNetworkInterface::IsUp) ||
            !(iface.flags() & QNetworkInterface::IsRunning))
            continue;

        for (const QNetworkAddressEntry &entry : iface.addressEntries())
        {
            if (entry.ip().protocol() == QAbstractSocket::IPv4Protocol &&
                entry.ip() != QHostAddress::LocalHost)
            {
                return entry.ip().toString();
            }
        }
    }
    return "";
}

void MulticastClient::start()
{
    log("CLIENT START");

    socket.setSocketOption(QAbstractSocket::ReceiveBufferSizeSocketOption, 64*1024*1024);

    socket.bind(QHostAddress::AnyIPv4, PORT, QUdpSocket::ShareAddress);
    socket.joinMulticastGroup(QHostAddress(MULTICAST_IP));

    while(true)
    {
        socket.waitForReadyRead();

        while(socket.hasPendingDatagrams())
        {
            QByteArray datagram;
            datagram.resize(socket.pendingDatagramSize());

            QHostAddress sender;
            socket.readDatagram(datagram.data(), datagram.size(), &sender);

            serverAddress = sender;
            processDatagram(datagram, sender);
        }
    }
}

void MulticastClient::processDatagram(const QByteArray &datagram, const QHostAddress &sender)
{
    QDataStream metaStream(datagram);
    quint32 type;
    metaStream >> type;

    // 🔥 META
    if(type == META)
    {
        quint64 tid;
        QString name, dir, transferType;
        bool overwrite;
        quint32 total;
        QStringList list;   // 🔥 yeni

        metaStream >> tid >> name >> dir >> transferType >> overwrite >> total >> list;

        currentTransferId = tid;
        fileName = name;
        targetDir = dir;
        totalPackets = total;

        this->overwrite = overwrite;
        this->transferType = transferType;

        allowedClients = list;

        QString myIp = getLocalIp();
        allowed = allowedClients.isEmpty() || allowedClients.contains(myIp);

        if(!allowed)
        {
            log(QString("NOT IN LIST (%1) → IGNORING").arg(myIp));
            return;
        }

        packets.resize(totalPackets);
        received.fill(false, totalPackets);

        log(QString("META: %1 (%2) overwrite=%3")
                .arg(fileName)
                .arg(transferType)
                .arg(overwrite));

        return;
    }

    // 🔥 liste dışıysa hiçbir şey yapma
    if(!allowed)
        return;

    if(datagram.size() < (int)sizeof(PacketHeader))
        return;

    PacketHeader header;
    memcpy(&header, datagram.data(), sizeof(header));

    if(header.transferId != currentTransferId)
        return;

    if(header.type == DATA)
    {
        if(header.index >= (quint32)packets.size())
            return;

        QByteArray data = datagram.mid(sizeof(header), header.dataSize);

        if(!received[header.index])
        {
            received[header.index] = true;
            packets[header.index] = data;
        }
    }
    else if(header.type == END)
    {
        QVector<quint32> missing;

        for(int i=0;i<received.size();i++)
            if(!received[i]) missing.push_back(i);

        if(!missing.isEmpty())
        {
            sendNack(missing, sender);
            return;
        }

        saveFile();
        resetState();
    }
}

void MulticastClient::sendNack(const QVector<quint32>& missing, const QHostAddress &sender)
{
    QUdpSocket nackSocket;

    QByteArray msg;
    QDataStream s(&msg,QIODevice::WriteOnly);

    s << (quint32)NACK;
    s << missing;

    QThread::msleep(2);
    nackSocket.writeDatagram(msg,sender,NACK_PORT);
}

void MulticastClient::saveFile()
{
    QString fullPath;

    if(overwrite)
        fullPath = targetDir + "/" + fileName;
    else
        fullPath = generateFileName(targetDir, fileName);

    QFile out(fullPath);

    if(!out.open(QIODevice::WriteOnly))
    {
        log("File write error");
        return;
    }

    for(const auto &p : packets)
        out.write(p);

    out.close();

    sendDone();

    log("FILE SAVED: " + fullPath);

    emit fileReceived(
        fullPath,
        fileName,
        QString::number(currentTransferId),
        transferType,
        overwrite
        );
}

QString MulticastClient::generateFileName(const QString& dir, const QString& baseName)
{
    QString fullPath = dir + "/" + baseName;

    if(!QFile::exists(fullPath))
        return fullPath;

    QFileInfo info(baseName);
    QString name = info.completeBaseName();
    QString ext = info.suffix();

    int i = 1;
    while(true)
    {
        QString newName = QString("%1(%2)").arg(name).arg(i);
        if(!ext.isEmpty())
            newName += "." + ext;

        QString newPath = dir + "/" + newName;

        if(!QFile::exists(newPath))
            return newPath;

        i++;
    }
}

void MulticastClient::sendDone()
{
    QUdpSocket s;

    QByteArray msg;
    QDataStream stream(&msg, QIODevice::WriteOnly);

    stream << (quint32)DONE;
    stream << currentTransferId;

    s.writeDatagram(msg, serverAddress, NACK_PORT);
}

void MulticastClient::resetState()
{
    packets.clear();
    received.clear();
    totalPackets = 0;
    currentTransferId = 0;
    allowed = true;

    log("READY FOR NEXT FILE");
}