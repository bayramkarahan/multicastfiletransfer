//#include <QCoreApplication>
#include "multicastfileserver.h"
#include "progressdialog.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    //QCoreApplication a(argc, argv);
QApplication a(argc, argv);
    // SERVER için
     //MulticastServer server(QString("/home/etapadmin/ab.deb"));
    //MulticastServer server("/home/etapadmin/ab.deb");
    ///server.start();
    MulticastServer server("/home/etapadmin/ab.deb");



        server.allowedClients << "192.168.1.101"
                            << "192.168.23.245"
                            << "192.168.23.241"
                            << "192.168.23.243"
                            << "192.168.23.231"
                            << "192.168.23.239"
                            << "192.168.23.233"
                            << "192.168.23.247"
                            << "192.168.23.235"
                            << "192.168.23.244"
                            << "192.168.23.250"
                            << "192.168.23.248"
                            << "192.168.23.251";
        ProgressDialog *dlg = new ProgressDialog(server.allowedClients);
        dlg->setAttribute(Qt::WA_DeleteOnClose);

        QObject::connect(&server, &MulticastServer::transferFinished,
                         [&](QString sender, QString receiver, QString file, QString id)
        {
            qDebug() <<"Client Tamamlandı: "<< sender << file << id;
            dlg->markDone(sender);
        });

        QObject::connect(&server,
                         &MulticastServer::clientProgressChanged,
                         [&](QString ip, int percent)
        {
            dlg->updateProgress(ip, percent);
            ///qDebug() <<"Transfer: "<< ip << percent;
        });

        QTimer::singleShot(0, [&](){
            server.start();
        });
    // CLIENT için ayrı program olarak çalıştırılacak
    // MulticastClient client;
    // client.start();

        dlg->show();
        dlg->updateProgress("192.168.1.77", 80);
        dlg->updateProgress("192.168.1.177", 20);
        dlg->updateProgress("192.168.1.88", 70);
       /* dlg->updateProgress("192.168.1.188", 50);
        dlg->updateProgress("192.168.1.190", 60);
        dlg->updateProgress("192.168.1.191", 25);
        dlg->updateProgress("192.168.1.192", 75);
        dlg->updateProgress("192.168.1.193", 65);
        dlg->updateProgress("192.168.1.181", 50);
        dlg->updateProgress("192.168.1.182", 60);
        dlg->updateProgress("192.168.1.183", 25);
        dlg->updateProgress("192.168.1.184", 75);
        dlg->updateProgress("192.168.1.185", 65);
        */
    return a.exec();
}
