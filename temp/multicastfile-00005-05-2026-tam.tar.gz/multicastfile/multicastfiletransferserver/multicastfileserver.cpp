#include "multicastfileserver.h"
#include <QDataStream>

MulticastServer::MulticastServer(const QString &filePath, QObject *parent)
    : QObject(parent), file(filePath), totalPackets(0)
{
    transferId = QDateTime::currentMSecsSinceEpoch();
}

void MulticastServer::log(const QString &msg)
{
    QString ts = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    qDebug() << ts << msg;
}

void MulticastServer::sendMeta()
{
    QByteArray msg;
    QDataStream stream(&msg, QIODevice::WriteOnly);

    QString fileName = QFileInfo(file.fileName()).fileName();
    QString targetDir = "/tmp";
    QString transferType = "deb";   // örnek: deb, image, config vs
    bool overwrite = false;         // 🔥 kritik

    stream << (quint32)META;
    stream << transferId;
    stream << fileName;
    stream << targetDir;
    stream << transferType;
    stream << overwrite;
    stream << (quint32)totalPackets;

    socket.writeDatagram(msg, QHostAddress(MULTICAST_IP), PORT);

    log(QString("META sent: %1 -> %2 overwrite=%3")
            .arg(fileName)
            .arg(targetDir)
            .arg(overwrite));
}

void MulticastServer::start()
{
    log("SERVER START");

    socket.setSocketOption(QAbstractSocket::SendBufferSizeSocketOption, 32*1024*1024);

    if(!file.open(QIODevice::ReadOnly))
    { log("File open error"); return; }

    fileData = file.readAll();
    totalPackets = (fileData.size()+PACKET_SIZE-1)/PACKET_SIZE;

    log(QString("File size %1").arg(fileData.size()));
    log(QString("Total packets %1").arg(totalPackets));

    nackSocket.bind(QHostAddress::AnyIPv4, NACK_PORT, QUdpSocket::ShareAddress);

    // 🔥 META gönder
    sendMeta();
    QThread::msleep(100);

    // DATA gönder
    for(int i=0;i<totalPackets;i++)
    {
        sendPacket(i);
        QThread::usleep(50);
    }

    sendEnd();
    log("END packet sent, waiting for NACKs");

    while(true)
    {
        QSet<quint32> missingAll;

        while(nackSocket.waitForReadyRead(3000))
        {
            while(nackSocket.hasPendingDatagrams())
            {
                QByteArray d;
                d.resize(nackSocket.pendingDatagramSize());

                QHostAddress sender;
                nackSocket.readDatagram(d.data(), d.size(), &sender);

                QDataStream s(d);
                quint32 type;
                s >> type;

                if(type==NACK)
                {
                    QVector<quint32> missing;
                    s >> missing;
                    missingAll.unite(QSet<quint32>(missing.begin(), missing.end()));
                }
            }
        }

        if(missingAll.isEmpty())
        {
            log("DONE");
            break;
        }

        log(QString("Resend %1").arg(missingAll.size()));

        for(auto idx: missingAll)
        {
            sendPacket(idx);
            QThread::usleep(50);
        }

        sendEnd();
    }
}

void MulticastServer::sendPacket(int index)
{
    QByteArray chunk = fileData.mid(index*PACKET_SIZE, PACKET_SIZE);

    PacketHeader header{DATA, transferId, (quint32)index, (quint32)totalPackets, (quint32)chunk.size()};

    QByteArray packet;
    packet.append((char*)&header,sizeof(header));
    packet.append(chunk);

    socket.writeDatagram(packet,QHostAddress(MULTICAST_IP),PORT);
}

void MulticastServer::sendEnd()
{
    PacketHeader h{END, transferId, 0, (quint32)totalPackets, 0};
    QByteArray p;
    p.append((char*)&h,sizeof(h));
    socket.writeDatagram(p,QHostAddress(MULTICAST_IP),PORT);
}