#include "multicastfiletransferclient.h"
#include <zlib.h>

QHostAddress group("239.255.0.1");
quint16 port = 45454;
quint16 ackPort = 45455;

QHostAddress serverIp("192.168.23.240");

MulticastFileTransferClient::MulticastFileTransferClient(QObject *parent)
    : QObject(parent)
{
    socket.bind(QHostAddress::AnyIPv4,
                port,
                QUdpSocket::ShareAddress |
                    QUdpSocket::ReuseAddressHint);

    socket.joinMulticastGroup(group);

    connect(&socket,&QUdpSocket::readyRead,
            this,&MulticastFileTransferClient::readPending);
}

void MulticastFileTransferClient::start()
{
}

void MulticastFileTransferClient::readPending()
{
    while(socket.hasPendingDatagrams())
    {
        QByteArray d;
        d.resize(socket.pendingDatagramSize());

        socket.readDatagram(d.data(), d.size());

        if(d.size() < (int)sizeof(PacketHeader))
            continue;

        PacketHeader h;
        memcpy(&h, d.constData(), sizeof(PacketHeader));

        if(h.type == META)
        {
            fileId = h.fileId;
            total  = h.total;

            QString name =
                QString::fromUtf8(
                    d.mid(sizeof(PacketHeader),h.size));

            currentFileName = name + ".part";

            file.setFileName(currentFileName);

            file.open(QIODevice::WriteOnly);
        }

        else if(h.type == DATA)
        {
            if(!file.isOpen())
                continue;

            QByteArray payload =
                d.mid(sizeof(PacketHeader),h.size);

            if(::crc32(0L,
                        reinterpret_cast<const Bytef*>(payload.constData()),
                        payload.size()) == h.crc)
            {
                file.seek(h.seq * CHUNK);
                file.write(payload);

                sendAck(h.seq);
            }
        }

        else if(h.type == END)
        {
            if(file.isOpen())
            {
                file.flush();
                file.close();

                QString finalName = currentFileName;

                if(finalName.endsWith(".part"))
                    finalName.chop(5);

                QFile::rename(currentFileName, finalName);

                emit transferFinished(finalName);

                sendDone();
            }
        }
    }
}

void MulticastFileTransferClient::sendAck(quint32 seq)
{
    PacketHeader h;

    h.type = ACK;
    h.fileId = fileId;
    h.seq = seq;
    h.total = total;
    h.size = 0;
    h.crc = 0;

    ackSocket.writeDatagram(
        reinterpret_cast<char*>(&h),
        sizeof(h),
        serverIp,
        ackPort);
}

void MulticastFileTransferClient::sendDone()
{
    PacketHeader h;

    h.type = DONE;
    h.fileId = fileId;
    h.seq = 0;
    h.total = total;
    h.size = 0;
    h.crc = 0;

    ackSocket.writeDatagram(
        reinterpret_cast<char*>(&h),
        sizeof(h),
        serverIp,
        ackPort);
}
