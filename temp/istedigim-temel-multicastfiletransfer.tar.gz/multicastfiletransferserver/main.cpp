#include "multicastfiletransferserver.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MulticastFileTransferServer server;
    server.sendFile("/home/etapadmin/ab.deb");
    return a.exec();
}
