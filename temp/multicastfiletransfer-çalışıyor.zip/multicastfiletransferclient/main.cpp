#include<multicastfiletransferclient.h>
#include <QCoreApplication>


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    qDebug()<<"Client başlıyor";
    MulticastFileClient client;
   /* MulticastFileTransferClient client;
    QObject::connect(&client,
                     &MulticastFileTransferClient::transferFinished,
                     [](QString file,
                        QString alt,
                        QString user,
                        QString type)
    {
        qDebug() << "Dosya:" << file;
        qDebug() << "Alternatif:" << alt;
        qDebug() << "Kullanıcı:" << user;
        qDebug() << "Type:" << type;
    });
    client.start();*/

    return a.exec();
}
