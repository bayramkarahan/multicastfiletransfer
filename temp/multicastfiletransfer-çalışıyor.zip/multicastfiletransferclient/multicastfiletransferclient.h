#ifndef MULTICASTFILECLIENT_H
#define MULTICASTFILECLIENT_H

#include <QObject>
#include <QUdpSocket>
#include <QBitArray>
#include <QVector>
#include <QFile>

#include "protocol.h"

class MulticastFileClient : public QObject
{
    Q_OBJECT

public:
    explicit MulticastFileClient(QObject *parent=nullptr);

private slots:
    void readPending();

private:

    void sendNack();
    void assembleFile();

    QUdpSocket socket;
    QUdpSocket controlSocket;

    QHostAddress group = QHostAddress("239.255.0.1");

    quint16 dataPort = 45454;
    quint16 controlPort = 45455;

    quint32 fileId=0;
    quint32 totalPackets=0;

    QString fileName;

    QVector<QByteArray> chunks;
    QBitArray received;

    const int CHUNK = 60000;
};

#endif
