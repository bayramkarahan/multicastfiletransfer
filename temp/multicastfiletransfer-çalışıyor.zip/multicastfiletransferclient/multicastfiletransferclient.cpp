#include "multicastfiletransferclient.h"
#include <QDir>
#include <QDebug>
#include <QNetworkInterface>
#include <zlib.h>

MulticastFileClient::MulticastFileClient(QObject *parent)
    : QObject(parent)
{
    qDebug()<<"Client başlatıldı";

    socket.bind(QHostAddress::AnyIPv4,
                dataPort,
                QUdpSocket::ShareAddress |
                QUdpSocket::ReuseAddressHint);

    socket.setSocketOption(
        QAbstractSocket::ReceiveBufferSizeSocketOption,
        64*1024*1024);

    bool joined=false;

    for(const QNetworkInterface &iface : QNetworkInterface::allInterfaces())
    {
        if(!(iface.flags() & QNetworkInterface::IsUp)) continue;
        if(!(iface.flags() & QNetworkInterface::IsRunning)) continue;
        if(iface.flags() & QNetworkInterface::IsLoopBack) continue;

        if(socket.joinMulticastGroup(group,iface))
        {
            qDebug()<<"Multicast join:"<<iface.humanReadableName();
            joined=true;
        }
    }

    if(!joined)
        qDebug()<<"Multicast join başarısız";

    connect(&socket,
            &QUdpSocket::readyRead,
            this,
            &MulticastFileClient::readPending);

    controlSocket.bind();
}

void MulticastFileClient::readPending()
{
    while(true)
    {
        if(!socket.hasPendingDatagrams())
            break;

        QByteArray d;
        d.resize(socket.pendingDatagramSize());

        socket.readDatagram(d.data(),d.size());

        if(d.size()<sizeof(PacketHeader))
            continue;

        PacketHeader h;
        memcpy(&h,d.constData(),sizeof(h));

        if(h.type==META)
        {
            fileId=h.fileId;
            totalPackets=h.total;

            fileName=QString::fromUtf8(
                d.mid(sizeof(PacketHeader),h.size));

            chunks.resize(totalPackets);
            received=QBitArray(totalPackets);
            received.fill(false);

            qDebug()<<"META alındı";
            qDebug()<<"Dosya:"<<fileName;
            qDebug()<<"Paket:"<<totalPackets;
        }

        else if(h.type==DATA)
        {
            if(h.fileId!=fileId)
                continue;

            QByteArray payload =
                d.mid(sizeof(PacketHeader),h.size);

            if(::crc32(0L,
                       reinterpret_cast<const Bytef*>(payload.constData()),
                       payload.size()) != h.crc)
                continue;

            if(!received.testBit(h.seq))
            {
                chunks[h.seq]=payload;
                received.setBit(h.seq,true);

                if(h.seq%500==0)
                    qDebug()<<"Paket:"<<h.seq;
            }
        }

        else if(h.type==END)
        {
            qDebug()<<"END alındı";
            sendNack();
        }
    }
}

void MulticastFileClient::sendNack()
{
    QVector<quint32> missing;

    for(int i=0;i<received.size();i++)
        if(!received.testBit(i))
            missing.append(i);

    qDebug()<<"Eksik paket:"<<missing.size();

    if(missing.isEmpty())
    {
        assembleFile();
        return;
    }

    QByteArray d;

    NackHeader h;
    h.type=NACK;
    h.fileId=fileId;
    h.count=missing.size();

    d.append((char*)&h,sizeof(h));

    for(quint32 s:missing)
        d.append((char*)&s,sizeof(s));

    controlSocket.writeDatagram(
        d,
        QHostAddress("239.255.0.1"),
        controlPort);

    qDebug()<<"NACK gönderildi";
}

void MulticastFileClient::assembleFile()
{
    QString path=QDir::homePath()+"/"+fileName;

    QFile f(path);

    if(!f.open(QIODevice::WriteOnly))
        return;

    for(int i=0;i<chunks.size();i++)
        f.write(chunks[i]);

    f.close();

    qDebug()<<"Dosya yazıldı:"<<path;
}
