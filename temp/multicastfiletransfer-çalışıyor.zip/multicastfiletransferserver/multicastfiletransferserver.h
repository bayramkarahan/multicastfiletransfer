#ifndef MULTICASTFILESERVER_H
#define MULTICASTFILESERVER_H

#include <QObject>
#include <QUdpSocket>
#include <QFile>
#include <QTimer>
#include "protocol.h"

class MulticastFileServer : public QObject
{
    Q_OBJECT

public:
    explicit MulticastFileServer(QObject *parent=nullptr);
    void sendFile(QString path);

private slots:
    void sendNext();
    void readNack();

private:

    void sendMeta(QString name);
    void sendChunk(quint32 seq);

    quint32 crc32(const QByteArray &data);

    QUdpSocket dataSocket;
    QUdpSocket controlSocket;

    QTimer sendTimer;

    QByteArray fileData;

    quint32 fileId;
    quint32 totalPackets;
    quint32 currentSeq;

    const int CHUNK = 60000;

    QHostAddress group = QHostAddress("239.255.0.1");
    quint16 dataPort = 45454;
    quint16 controlPort = 45455;
};

#endif
