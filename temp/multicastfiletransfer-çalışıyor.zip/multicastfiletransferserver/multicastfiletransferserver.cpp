#include "multicastfiletransferserver.h"
#include <QFileInfo>
#include <QDateTime>
#include <QDebug>
#include <zlib.h>

MulticastFileServer::MulticastFileServer(QObject *parent)
    : QObject(parent)
{
    qDebug()<<"Server başlatıldı";

    dataSocket.setSocketOption(QAbstractSocket::SendBufferSizeSocketOption,
                               64*1024*1024);

    controlSocket.bind(QHostAddress::AnyIPv4,
                       controlPort,
                       QUdpSocket::ShareAddress);

    connect(&controlSocket,
            &QUdpSocket::readyRead,
            this,
            &MulticastFileServer::readNack);

    connect(&sendTimer,
            &QTimer::timeout,
            this,
            &MulticastFileServer::sendNext);

    sendTimer.setInterval(1);   // 🔥 kritik
}

void MulticastFileServer::sendFile(QString path)
{
    QFile f(path);

    if(!f.open(QIODevice::ReadOnly))
        return;

    fileData=f.readAll();
    f.close();

    fileId=QDateTime::currentSecsSinceEpoch();

    totalPackets=(fileData.size()+CHUNK-1)/CHUNK;

    QFileInfo fi(path);

    qDebug()<<"Dosya:"<<fi.fileName();
    qDebug()<<"Boyut:"<<fileData.size();
    qDebug()<<"Paket:"<<totalPackets;

    sendMeta(fi.fileName());

    currentSeq=0;

    sendTimer.start();
}

void MulticastFileServer::sendNext()
{
    const int BURST = 16;

    for(int i=0;i<BURST;i++)
    {
        if(currentSeq>=totalPackets)
        {
            PacketHeader h{};
            h.type=END;
            h.fileId=fileId;

            dataSocket.writeDatagram((char*)&h,
                                     sizeof(h),
                                     group,
                                     dataPort);

            qDebug()<<"END gönderildi";

            sendTimer.stop();
            return;
        }

        sendChunk(currentSeq);

        if(currentSeq%2000==0)
            qDebug()<<"Gönderilen:"<<currentSeq;

        currentSeq++;
    }
}

void MulticastFileServer::sendMeta(QString name)
{
    QByteArray n=name.toUtf8();

    PacketHeader h{};
    h.type=META;
    h.fileId=fileId;
    h.total=totalPackets;
    h.size=n.size();

    QByteArray d;

    d.append((char*)&h,sizeof(h));
    d.append(n);

    dataSocket.writeDatagram(d,
                             group,
                             dataPort);

    qDebug()<<"META gönderildi";
}

void MulticastFileServer::sendChunk(quint32 seq)
{
    QByteArray chunk=fileData.mid(seq*CHUNK,CHUNK);

    PacketHeader h{};
    h.type=DATA;
    h.fileId=fileId;
    h.seq=seq;
    h.total=totalPackets;
    h.size=chunk.size();
    h.crc=crc32(chunk);

    QByteArray d;

    d.append((char*)&h,sizeof(h));
    d.append(chunk);

    dataSocket.writeDatagram(d,
                             group,
                             dataPort);
}

void MulticastFileServer::readNack()
{
    while(controlSocket.hasPendingDatagrams())
    {
        QByteArray d;

        d.resize(controlSocket.pendingDatagramSize());

        QHostAddress sender;
        quint16 port;

        controlSocket.readDatagram(d.data(),
                                   d.size(),
                                   &sender,
                                   &port);

        if(d.size()<sizeof(NackHeader))
            return;

        NackHeader h;

        memcpy(&h,d.constData(),sizeof(h));

        if(h.type!=NACK)
            return;

        qDebug()<<"NACK geldi:"<<h.count;

        const quint32 *list=
                (quint32*)(d.constData()+sizeof(NackHeader));

        for(quint32 i=0;i<h.count;i++)
        {
            quint32 seq=list[i];

            if(seq<totalPackets)
                sendChunk(seq);
        }
    }
}

quint32 MulticastFileServer::crc32(const QByteArray &data)
{
    return ::crc32(0L,
                   reinterpret_cast<const Bytef*>(data.constData()),
                   data.size());
}
