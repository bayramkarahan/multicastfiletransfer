#include "multicastfiletransferserver.h"
#include <QCoreApplication>
#include <QDebug>
#include <QProcess>

void setUdpBuffers()
{
    // Linux sistemde kernel parametrelerini değiştir
    QProcess::execute("sysctl -w net.core.rmem_max=134217728");
    QProcess::execute("sysctl -w net.core.rmem_default=134217728");
    QProcess::execute("sysctl -w net.core.wmem_max=134217728");
    QProcess::execute("sysctl -w net.core.wmem_default=134217728");

    qDebug() << "UDP buffer ayarları varsayılan yapıldı (128MB)";
}

int main(int argc,char *argv[])
{
    QCoreApplication a(argc,argv);


    qDebug()<<"Server hazır";
    MulticastFileServer server;
//setUdpBuffers();
        server.sendFile("/home/etapadmin/ab.deb");
   /* MulticastFileTransferServer server;
    QObject::connect(&server,
                     &MulticastFileTransferServer::clientFinished,
                     [&](QHostAddress client, quint32 fileId)
                     {
                         qDebug() << "Client tamamladı:" << client.toString()
                                  << "fileId:" << fileId;

                         // burada client'a özel işlem yapabilirsin
                     });

    QList<QHostAddress> selected;
    selected << QHostAddress("192.168.1.100");
    QHostAddress serverIp("192.168.1.102");

    server.sendFile("/home/etapadmin/ab.deb",
                    serverIp, selected,false,"/tmp",
                    "abc.hh","etap","homefile");*/
    return a.exec();
}
