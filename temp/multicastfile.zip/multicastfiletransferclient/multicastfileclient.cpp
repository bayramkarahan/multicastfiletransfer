#include "multicastfileclient.h"

MulticastClient::MulticastClient(QObject *parent)
    : QObject(parent), totalPackets(0)
{}

void MulticastClient::log(const QString &msg)
{
    QString ts = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    qDebug() << ts << msg;
}

void MulticastClient::start()
{
    log("CLIENT START");

    socket.setSocketOption(QAbstractSocket::ReceiveBufferSizeSocketOption,32*1024*1024);
    if(!socket.bind(QHostAddress::AnyIPv4,PORT,QUdpSocket::ShareAddress))
    { log("Bind error"); return; }

    if(!socket.joinMulticastGroup(QHostAddress(MULTICAST_IP)))
    { log("Multicast join error"); return; }

    log("Joined multicast group");

    bool done=false;
    while(!done)
    {
        socket.waitForReadyRead();

        while(socket.hasPendingDatagrams())
        {
            QByteArray datagram;
            datagram.resize(socket.pendingDatagramSize());

            QHostAddress sender;
            quint16 senderPort;
            socket.readDatagram(datagram.data(),datagram.size(),&sender,&senderPort);

            serverAddress = sender;
            processDatagram(datagram, sender);

            bool allReceived = true;
            for(bool r : received) { if(!r){ allReceived=false; break; } }

            if(totalPackets>0 && allReceived)
            {
                QFile out("output.bin");
                out.open(QIODevice::WriteOnly);
                for(auto &p: packets) out.write(p);
                out.close();
                log("All packets received. File saved. PROCESS COMPLETE.");
                done=true;
            }
        }
    }
}

void MulticastClient::processDatagram(const QByteArray &datagram, const QHostAddress &sender)
{
    PacketHeader header;
    memcpy(&header, datagram.data(), sizeof(header));

    if(header.type==DATA)
    {
        if(totalPackets==0)
        {
            totalPackets = header.totalPackets;
            packets.resize(totalPackets);
            received.resize(totalPackets);
            log(QString("Total packets %1").arg(totalPackets));
        }

        QByteArray data = datagram.mid(sizeof(header), header.dataSize);
        if(!received[header.index])
        {
            received[header.index]=true;
            packets[header.index]=data;
        }
    }
    else if(header.type==END)
    {
        log("END received");

        QVector<quint32> missing;
        for(int i=0;i<received.size();i++)
            if(!received[i]) missing.push_back(i);

        QThread::msleep(500); // kısa bekleme
        if(!missing.isEmpty())
        {
            log(QString("Missing packets count %1").arg(missing.size()));

            QUdpSocket nackSocket;

            const int BATCH_SIZE = 2000; // 50 client için daha güvenli
            for(int i=0;i<missing.size();i+=BATCH_SIZE)
            {
                QVector<quint32> part = missing.mid(i, BATCH_SIZE);
                QByteArray msg;
                QDataStream stream(&msg,QIODevice::WriteOnly);
                stream<<(quint32)NACK;
                stream<<part;

                // Random delay 0-10 ms ile burst azalt
                QThread::msleep(QRandomGenerator::global()->bounded(10));
                nackSocket.writeDatagram(msg,sender,NACK_PORT);
                log(QString("NACK batch sent (%1 packets)").arg(part.size()));
            }

            log(QString("All NACK batches sent to %1").arg(sender.toString()));
        }
    }
}
