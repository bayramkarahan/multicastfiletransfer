#include <QCoreApplication>

#include "multicastfileclient.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);


    // CLIENT için ayrı program olarak çalıştırılacak

     MulticastClient client;
     client.start();

    return a.exec();
}
