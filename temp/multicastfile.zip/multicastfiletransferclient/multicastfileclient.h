#pragma once
#include <QObject>
#include <QUdpSocket>
#include <QVector>
#include <QThread>
#include <QFile>
#include <QDebug>
#include <QDataStream>
#include <QDateTime>
#include <QRandomGenerator>

#define MULTICAST_IP "239.255.0.1"
#define PORT 45454
#define NACK_PORT 45455
#define DATA 1
#define END 2
#define NACK 3

struct PacketHeader
{
    quint32 type;
    quint32 index;
    quint32 totalPackets;
    quint32 dataSize;
};

class MulticastClient : public QObject
{
    Q_OBJECT
public:
    explicit MulticastClient(QObject *parent=nullptr);
    void start();

private:
    void log(const QString &msg);
    void processDatagram(const QByteArray &datagram, const QHostAddress &sender);

    QUdpSocket socket;
    QHostAddress serverAddress;
    QVector<QByteArray> packets;
    QVector<bool> received;
    int totalPackets;
};
