#include <QCoreApplication>
#include "multicastfileserver.h"


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // SERVER için
     //MulticastServer server(QString("/home/etapadmin/ab.deb"));
    MulticastServer server("/home/etapadmin/ab.deb");
    server.start();

    // CLIENT için ayrı program olarak çalıştırılacak
    // MulticastClient client;
    // client.start();

    return a.exec();
}
