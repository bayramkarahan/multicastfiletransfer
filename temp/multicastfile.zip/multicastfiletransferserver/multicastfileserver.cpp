#include "multicastfileserver.h"
#include <QDataStream>

MulticastServer::MulticastServer(const QString &filePath, QObject *parent)
    : QObject(parent), file(filePath), totalPackets(0)
{}

void MulticastServer::log(const QString &msg)
{
    QString ts = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    qDebug() << ts << msg;
}

void MulticastServer::start()
{
    log("SERVER START");

    socket.setSocketOption(QAbstractSocket::SendBufferSizeSocketOption, 32*1024*1024);
    socket.setSocketOption(QAbstractSocket::ReceiveBufferSizeSocketOption, 32*1024*1024);

    if(!file.open(QIODevice::ReadOnly)) { log("File open error"); return; }

    fileData = file.readAll();
    totalPackets = (fileData.size()+PACKET_SIZE-1)/PACKET_SIZE;

    log(QString("File size %1").arg(fileData.size()));
    log(QString("Total packets %1").arg(totalPackets));

    if(!nackSocket.bind(QHostAddress::AnyIPv4, NACK_PORT, QUdpSocket::ShareAddress))
    { log("NACK socket bind error"); return; }

    // Initial send
    for(int i=0;i<totalPackets;i++)
    {
        sendPacket(i);
        //if(i%2==0)
            QThread::usleep(200);
    }

    QThread::msleep(300);

    // END paketi
    PacketHeader endHeader{END,0,totalPackets,0};
    QByteArray endPacket;
    endPacket.append((char*)&endHeader,sizeof(endHeader));
    socket.writeDatagram(endPacket,QHostAddress(MULTICAST_IP),PORT);

    log("END packet sent, waiting for NACKs");
 QThread::msleep(300);
    // NACK toplama ve tek resend mantığı
    while(true)
    {
        QSet<quint32> missingAll;

        // 5 saniye boyunca tüm NACK’leri oku ve birleştir
        while(nackSocket.waitForReadyRead(5000))
        {
            while(nackSocket.hasPendingDatagrams())
            {
                QByteArray datagram;
                datagram.resize(nackSocket.pendingDatagramSize());

                QHostAddress sender;
                quint16 senderPort;
                nackSocket.readDatagram(datagram.data(), datagram.size(), &sender, &senderPort);

                QDataStream stream(datagram);
                quint32 type;
                stream >> type;

                if(type==NACK)
                {
                    QVector<quint32> missing;
                    stream >> missing;
                    missingAll.unite(QSet<quint32>(missing.begin(), missing.end()));
                    log(QString("NACK received from %1, missing %2 packets")
                        .arg(sender.toString()).arg(missing.size()));
                }
            }
        }

        if(missingAll.isEmpty())
        {
            log("No more NACKs, server done.");
            break;
        }

        // Tek seferde tüm eksikleri gönder
        log(QString("Total merged missing packets %1, resending...").arg(missingAll.size()));
        resendPackets(QVector<quint32>(missingAll.begin(), missingAll.end()));
    }

    log("SERVER PROCESS COMPLETE");
}

void MulticastServer::sendPacket(int index)
{
    PacketHeader header{DATA, index, totalPackets, 0};
    QByteArray chunk = fileData.mid(index*PACKET_SIZE, PACKET_SIZE);
    header.dataSize = chunk.size();

    QByteArray packet;
    packet.append((char*)&header,sizeof(header));
    packet.append(chunk);

    socket.writeDatagram(packet,QHostAddress(MULTICAST_IP),PORT);
}

void MulticastServer::resendPackets(const QVector<quint32>& missing)
{
    for(quint32 idx : missing)
    {
        sendPacket(idx);
        //if(idx % 2 == 0)
            QThread::usleep(200);
    }

    QThread::msleep(300);
    PacketHeader endHeader{END,0,totalPackets,0};
    QByteArray endPacket;
    endPacket.append((char*)&endHeader,sizeof(endHeader));
    socket.writeDatagram(endPacket,QHostAddress(MULTICAST_IP),PORT);
    log("END packet resent after resend");
    QThread::msleep(200);
}
