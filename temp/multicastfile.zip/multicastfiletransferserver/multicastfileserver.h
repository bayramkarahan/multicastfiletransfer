#pragma once
#include <QObject>
#include <QUdpSocket>
#include <QFile>
#include <QVector>
#include <QThread>
#include <QDateTime>
#include <QSet>
#include <QDebug>

#define MULTICAST_IP "239.255.0.1"
#define PORT 45454
#define NACK_PORT 45455
#define PACKET_SIZE 1312   // ~1.3 KB
#define DATA 1
#define END 2
#define NACK 3

struct PacketHeader
{
    quint32 type;
    quint32 index;
    quint32 totalPackets;
    quint32 dataSize;
};

class MulticastServer : public QObject
{
    Q_OBJECT
public:
    explicit MulticastServer(const QString &filePath, QObject *parent = nullptr);
    void start();

private:
    void log(const QString &msg);
    void sendPacket(int index);
    void resendPackets(const QVector<quint32>& missing);

    QUdpSocket socket;
    QUdpSocket nackSocket;
    QFile file;
    QByteArray fileData;
    int totalPackets;
};
