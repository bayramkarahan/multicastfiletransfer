#include "multicastfileserver.h"
#include <QDataStream>

MulticastServer::MulticastServer(const QString &filePath, QObject *parent)
    : QObject(parent), file(filePath), totalPackets(0)
{
    transferId = QDateTime::currentMSecsSinceEpoch();
    transferIdStr = QString::number(transferId);
    fileName = QFileInfo(file.fileName()).fileName();
}

void MulticastServer::log(const QString &msg)
{
    QString ts = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    qDebug() << ts << msg;
}

void MulticastServer::sendMeta()
{
    QByteArray msg;
    QDataStream stream(&msg, QIODevice::WriteOnly);

    QString fileName = QFileInfo(file.fileName()).fileName();
    QString targetDir = "/tmp";
    QString transferType = "deb";   // örnek: deb, image, config vs
    bool overwrite = false;         // 🔥 kritik

    stream << (quint32)META;
    stream << transferId;
    stream << fileName;
    stream << targetDir;
    stream << transferType;
    stream << overwrite;
    stream << (quint32)totalPackets;
    stream << allowedClients;

    socket.writeDatagram(msg, QHostAddress(MULTICAST_IP), PORT);

    log(QString("META sent: %1 -> %2 overwrite=%3")
            .arg(fileName)
            .arg(targetDir)
            .arg(overwrite));
}

void MulticastServer::start()
{
    log("SERVER START");

    delayUs = detectDefaultDelay();
    log(QString("Initial delay: %1 us").arg(delayUs));

    socket.setSocketOption(QAbstractSocket::SendBufferSizeSocketOption, 32*1024*1024);

    if(!file.open(QIODevice::ReadOnly))
    {
        log("File open error");
        return;
    }

    fileData = file.readAll();
    totalPackets = (fileData.size()+PACKET_SIZE-1)/PACKET_SIZE;

    log(QString("File size %1").arg(fileData.size()));
    log(QString("Total packets %1").arg(totalPackets));

    // 🔥 NACK dinlemeyi EN BAŞTA aç
    nackSocket.bind(QHostAddress::AnyIPv4, NACK_PORT, QUdpSocket::ShareAddress);

    connect(&nackSocket,
            SIGNAL(readyRead()),
            this,
            SLOT(processPendingDatagrams()));

    // META
    sendMeta();
    QThread::msleep(100);

    int burst = calculateBurst(delayUs);

    QTimer::singleShot(1000, this, [this, burst]()
                       {
                           currentIndex = 0;

                           connect(&sendTimer, &QTimer::timeout, this, [this, burst]()
                                   {
                                       for(int i = 0; i < burst && currentIndex < totalPackets; i++)
                                       {
                                           sendPacket(currentIndex++);
                                       }

                                       if(currentIndex >= totalPackets)
                                       {
                                           sendTimer.stop();
                                           sendEnd();
                                           log("END packet sent, waiting for NACKs");
                                       }
                                   });

                           sendTimer.start(1);
                       });


    // sendTimer.start(50); // 🔥 0 DEĞİL!
}


void MulticastServer::sendPacket(int index)
{
    QByteArray chunk = fileData.mid(index*PACKET_SIZE, PACKET_SIZE);

    PacketHeader header{DATA, transferId, (quint32)index, (quint32)totalPackets, (quint32)chunk.size()};

    QByteArray packet;
    packet.append((char*)&header,sizeof(header));
    packet.append(chunk);

    socket.writeDatagram(packet,QHostAddress(MULTICAST_IP),PORT);
}

void MulticastServer::sendEnd()
{
    PacketHeader h{END, transferId, 0, (quint32)totalPackets, 0};
    QByteArray p;
    p.append((char*)&h,sizeof(h));
    socket.writeDatagram(p,QHostAddress(MULTICAST_IP),PORT);
}

int MulticastServer::detectDefaultDelay()
{
    QString type = detectNetworkType();

    if(type == "wifi")
    {
        log("Network: WIFI");
        return 180;
    }
    else if(type == "ethernet")
    {
        log("Network: ETHERNET");
        return 50;
    }

    log("Network: UNKNOWN");
    return 100;
}
QString MulticastServer::getDefaultInterface()
{
    QFile f("/proc/net/route");
    if(!f.open(QIODevice::ReadOnly))
        return "";

    while(!f.atEnd())
    {
        QByteArray line = f.readLine();
        QList<QByteArray> parts = line.split('\t');

        if(parts.size() > 1 && parts[1] == "00000000")
        {
            return parts[0];
        }
    }

    return "";
}


QString MulticastServer::detectNetworkType()
{
    QString activeIface;

    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces())
    {
        //log(QString("%1 | %2")
        //   .arg(iface.name())
        // .arg(iface.humanReadableName()));

        // sadece çalışanlar
        if (!(iface.flags() & QNetworkInterface::IsUp) ||
            !(iface.flags() & QNetworkInterface::IsRunning))
            continue;

        // loopback skip
        if (iface.flags() & QNetworkInterface::IsLoopBack)
            continue;

        // IP var mı?
        for (const QNetworkAddressEntry &entry : iface.addressEntries())
        {
            if (entry.ip().protocol() == QAbstractSocket::IPv4Protocol)
            {
                activeIface = iface.name();
                log("ACTIVE IFACE: " + activeIface);

                // 🔥 Linux naming standard
                if (activeIface.startsWith("wl"))
                    return "wifi";

                if (activeIface.startsWith("en") || activeIface.startsWith("eth"))
                    return "ethernet";

                return "unknown";
            }
        }
    }

    return "unknown";
}


void MulticastServer::processPendingDatagrams()
{
    QSet<quint32> missingAll;

    while(nackSocket.hasPendingDatagrams())
    {
        QByteArray d;
        d.resize(nackSocket.pendingDatagramSize());

        QHostAddress sender;
        nackSocket.readDatagram(d.data(), d.size(), &sender);

        QDataStream s(d);
        quint32 type;
        s >> type;

        if(type==NACK)
        {
            QVector<quint32> missing;
            s >> missing;

            QString ip = sender.toString();
            allClients.insert(ip);
            lastMissingCount[ip] = missing.size();

            log(QString("NACK from %1 missing=%2")
                    .arg(ip)
                    .arg(missing.size()));

            missingAll.unite(QSet<quint32>(missing.begin(), missing.end()));
        }
        else if(type==DONE)
        {
            quint64 tid;
            s >> tid;

            if(tid == transferId)
            {
                QString ip = sender.toString();

                if(!completedClients.contains(ip))
                {
                    completedClients.insert(ip);

                    log(QString("CLIENT DONE: %1").arg(ip));

                    emit transferFinished(
                        ip,
                        "server",
                        fileName,
                        transferIdStr
                        );
                }
            }
        }
        else if(type == PROGRESS)
        {
            quint64 tid;
            int percent;

            s >> tid >> percent;

            if(tid == transferId)
            {
                QString ip = sender.toString();

                clientProgress[ip] = percent;

                emit clientProgressChanged(ip, percent);
            }
        }
    }

    // 🔥 resend logic (tek seferlik çalışır, bloklamaz)
    if(!missingAll.isEmpty())
    {
        log(QString("Resend %1").arg(missingAll.size()));

        for(auto idx: missingAll)
        {
            sendPacket(idx);
            QThread::usleep(delayUs);
        }

        sendEnd();
    }
}


int MulticastServer::calculateBurst(int delayUs)
{
    if(delayUs <= 50)   return 8;
    if(delayUs <= 100)  return 6;
    if(delayUs <= 200)  return 5;
    return 3;
}