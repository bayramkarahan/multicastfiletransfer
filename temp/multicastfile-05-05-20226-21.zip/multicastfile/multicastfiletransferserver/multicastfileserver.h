#pragma once
#include <QObject>
#include <QUdpSocket>
#include <QFile>
#include <QVector>
#include <QThread>
#include <QDateTime>
#include <QSet>
#include <QDebug>
#include <QFileInfo>

#define MULTICAST_IP "239.255.0.1"
#define PORT 45454
#define NACK_PORT 45455
#define PACKET_SIZE 1312

#define META 0
#define DATA 1
#define END 2
#define NACK 3

struct PacketHeader
{
    quint32 type;
    quint64 transferId;
    quint32 index;
    quint32 totalPackets;
    quint32 dataSize;
};

class MulticastServer : public QObject
{
    Q_OBJECT
public:
    explicit MulticastServer(const QString &filePath, QObject *parent = nullptr);
    void start();

private:
    void log(const QString &msg);
    void sendPacket(int index);
    void resendPackets(const QVector<quint32>& missing);
    void sendMeta();
    void sendEnd();

    QUdpSocket socket;
    QUdpSocket nackSocket;
    QFile file;
    QByteArray fileData;
    int totalPackets;

    quint64 transferId;
    int delayUs = 100;
    QSet<QHostAddress> allClients;
    QSet<QHostAddress> completedClients;
    QMap<QHostAddress, int> lastMissingCount;
};
