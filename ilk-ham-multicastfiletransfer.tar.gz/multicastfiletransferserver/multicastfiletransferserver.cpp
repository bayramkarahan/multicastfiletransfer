#include "multicastfiletransferserver.h"
#include <QDateTime>
#include <QDataStream>
#include <zlib.h>

QHostAddress group("239.255.0.1");
quint16 port = 75454;
quint16 ackPort = 75455;

MulticastFileTransferServer::MulticastFileTransferServer(QObject *parent)
    : QObject(parent)
{
    // Multicast TTL (subnet geçişi için)
    dataSocket.setSocketOption(
        QAbstractSocket::MulticastTtlOption, 16);

    ackSocket.bind(QHostAddress::AnyIPv4,
                   ackPort,
                   QUdpSocket::ShareAddress);

    connect(&ackSocket, &QUdpSocket::readyRead,
            this, &MulticastFileTransferServer::processAck);

    resendTimer.setInterval(200);
    connect(&resendTimer, &QTimer::timeout,
            this, &MulticastFileTransferServer::resendTimeout);
}

void MulticastFileTransferServer::sendFile(const QString &path)
{
    file.setFileName(path);

    if(!file.open(QIODevice::ReadOnly))
        return;

    fileData = file.readAll();
    file.close();

    fileId = QDateTime::currentSecsSinceEpoch();
    totalPackets = (fileData.size() / CHUNK) + 1;

    QFileInfo fi(path);
    QString fullname = fi.fileName();

    sendMeta(fullname);

    resendTimer.start();

    while(base < totalPackets)
    {
        while(next < base + WINDOW && next < totalPackets)
            sendChunk(next++);

        QCoreApplication::processEvents();
    }

    // END paketi
    PacketHeader h;
    h.type = END;
    h.fileId = fileId;
    h.seq = 0;
    h.total = totalPackets;
    h.size = 0;
    h.crc = 0;

    dataSocket.writeDatagram(
        reinterpret_cast<char*>(&h),
        sizeof(h),
        group,
        port);

    resendTimer.stop();
}

void MulticastFileTransferServer::sendMeta(const QString &fullname)
{
    QByteArray name = fullname.toUtf8();

    PacketHeader h;
    h.type = META;
    h.fileId = fileId;
    h.seq = 0;
    h.total = totalPackets;
    h.size = name.size();
    h.crc = 0;

    QByteArray d;
    d.append(reinterpret_cast<char*>(&h), sizeof(h));
    d.append(name);

    dataSocket.writeDatagram(d, group, port);
}

void MulticastFileTransferServer::sendChunk(quint32 seq)
{
    QByteArray chunk = fileData.mid(seq * CHUNK, CHUNK);

    PacketHeader h;
    h.type = DATA;
    h.fileId = fileId;
    h.seq = seq;
    h.total = totalPackets;
    h.size = chunk.size();
    h.crc = crc32(chunk);

    QByteArray d;
    d.append(reinterpret_cast<char*>(&h), sizeof(h));
    d.append(chunk);

    window[seq] = d;

    dataSocket.writeDatagram(d, group, port);
}

void MulticastFileTransferServer::processAck()
{
    while(ackSocket.hasPendingDatagrams())
    {
        QByteArray data;
        data.resize(ackSocket.pendingDatagramSize());
        ackSocket.readDatagram(data.data(), data.size());

        quint32 seq;
        memcpy(&seq, data.constData(), sizeof(seq));

        acked.insert(seq);

        while(acked.contains(base))
        {
            acked.remove(base);
            window.remove(base);
            base++;
        }
    }
}

void MulticastFileTransferServer::resendTimeout()
{
    for(auto it = window.begin(); it != window.end(); ++it)
    {
        if(!acked.contains(it.key()))
        {
            dataSocket.writeDatagram(it.value(),
                                     group,
                                     port);
        }
    }
}

quint32 MulticastFileTransferServer::crc32(const QByteArray &data)
{
    return ::crc32(0L,
                   reinterpret_cast<const Bytef*>(data.constData()),
                   data.size());
}
