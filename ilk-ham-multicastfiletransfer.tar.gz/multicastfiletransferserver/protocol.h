#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <QtGlobal>

#pragma pack(push,1)
struct PacketHeader
{
    quint8  type;        // 1=Meta 2=Data 3=End
    quint32 fileId;
    quint32 seq;
    quint32 total;
    quint32 size;
    quint32 crc;
};
#pragma pack(pop)

enum PacketType
{
    META = 1,
    DATA = 2,
    END  = 3,
    ACK  = 4
};

#endif
