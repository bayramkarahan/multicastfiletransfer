#include<multicastfiletransferclient.h>
#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MulticastFileTransferClient client;
    client.start();
    return a.exec();
}
