#ifndef MULTICASTFILETRANSFERCLIENT_H
#define MULTICASTFILETRANSFERCLIENT_H

#include <QObject>
#include <QUdpSocket>
#include <QFile>
#include <QMap>
#include <QHostAddress>

#include "protocol.h"

class MulticastFileTransferClient : public QObject
{
    Q_OBJECT
public:
    explicit MulticastFileTransferClient(QObject *parent=nullptr);
    void start();

signals:
    void transferFinished(QString fileName);

private slots:
    void readPending();

private:
    void sendAck(quint32 seq);

    QUdpSocket socket;
    QUdpSocket ackSocket;

    QFile file;
    QString currentFileName;

    QMap<quint32,QByteArray> buffer;

    quint32 total = 0;
    quint32 fileId = 0;
};

#endif
