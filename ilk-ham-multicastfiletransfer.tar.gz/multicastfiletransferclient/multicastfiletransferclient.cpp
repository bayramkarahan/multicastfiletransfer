#include "multicastfiletransferclient.h"
#include <zlib.h>
#include <QFileInfo>

QHostAddress group("239.255.0.1");
quint16 port = 75454;
quint16 ackPort = 75455;
QHostAddress serverIp("192.168.23.240");  // ACK için gerekli

MulticastFileTransferClient::MulticastFileTransferClient(QObject *parent)
    : QObject(parent)
{
    socket.bind(QHostAddress::AnyIPv4,
                port,
                QUdpSocket::ShareAddress |
                    QUdpSocket::ReuseAddressHint);

    socket.joinMulticastGroup(group);

    connect(&socket, &QUdpSocket::readyRead,
            this, &MulticastFileTransferClient::readPending);
}

void MulticastFileTransferClient::start()
{
    // Gerekirse REGISTER mesajı burada gönderilebilir
}

void MulticastFileTransferClient::readPending()
{
    while(socket.hasPendingDatagrams())
    {
        QByteArray d;
        d.resize(socket.pendingDatagramSize());
        socket.readDatagram(d.data(), d.size());

        if(d.size() < (int)sizeof(PacketHeader))
            continue;

        PacketHeader h;
        memcpy(&h, d.constData(), sizeof(PacketHeader));

        // ---------------- META ----------------
        if(h.type == META)
        {
            fileId = h.fileId;
            total  = h.total;

            QString fileName = QString::fromUtf8(
                d.mid(sizeof(PacketHeader), h.size));

            currentFileName = fileName + ".part";

            file.setFileName(currentFileName);

            if(!file.open(QIODevice::WriteOnly))
            {
                qDebug() << "File open failed!";
                return;
            }

            buffer.clear();
        }

        // ---------------- DATA ----------------
        else if(h.type == DATA)
        {
            if(!file.isOpen())
                continue;

            QByteArray payload =
                d.mid(sizeof(PacketHeader), h.size);

            if(::crc32(0L,
                        (Bytef*)payload.data(),
                        payload.size()) == h.crc)
            {
                buffer[h.seq] = payload;
                sendAck(h.seq);
            }

            if(total > 0 && buffer.size() == total)
            {
                for(quint32 i=0;i<total;i++)
                    file.write(buffer[i]);

                file.flush();
                file.close();

                // .part → final isim
                QString finalName = currentFileName;
                finalName.chop(5); // ".part" sil

                QFile::rename(currentFileName, finalName);

                emit transferFinished(finalName);
            }
        }

        // ---------------- END ----------------
        else if(h.type == END)
        {
            if(file.isOpen())
            {
                file.flush();
                file.close();

                QString finalName = currentFileName;
                if(finalName.endsWith(".part"))
                {
                    finalName.chop(5);
                    QFile::rename(currentFileName, finalName);
                    emit transferFinished(finalName);
                }
            }
        }
    }
}

void MulticastFileTransferClient::sendAck(quint32 seq)
{
    ackSocket.writeDatagram(reinterpret_cast<char*>(&seq),
                            sizeof(seq),
                            serverIp,
                            ackPort);
}
